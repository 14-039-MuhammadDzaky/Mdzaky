<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="platforms" tilewidth="64" tileheight="64" tilecount="8" columns="4">
 <image source="../../asset/tilesets/platforms.png" width="256" height="128"/>
</tileset>
